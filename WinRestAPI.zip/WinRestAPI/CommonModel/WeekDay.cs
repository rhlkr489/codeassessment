﻿using System;

namespace CommonModel
{
    public class WeekDay
    {
        public string WeekOfDay { get; set; }
        public bool hasParameter { get; set; }
        public  DateTime CurrentDate { get; set; }
    }
}
