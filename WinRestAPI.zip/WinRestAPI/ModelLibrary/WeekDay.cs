﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ModelLibrary
{
    public class WeekDay
    {
        public string DayOfWeek { get; set; }
        public bool UrlSpecified { get; set; }


    }
}
