﻿using CommonModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WinRestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserWeekdayController : ControllerBase
    {
        private static readonly List<WeekDay> totalWeekDays = new List<WeekDay>();

        // GET: api/<UserWeekdayController>
        [HttpGet]
        public IEnumerable<WeekDay> Get(bool? input)
        {
            var currentDate = DateTime.Now;
            totalWeekDays.AddRange(GetWeekDays(currentDate, input));
            return totalWeekDays;
        }

        // POST api/<UserWeekdayController>
        [HttpPost]
        public IActionResult Post([FromBody] IEnumerable<WeekDay> weekDays)
        {
            if (weekDays.Any())
            {
                totalWeekDays.AddRange(weekDays);
                return Ok(totalWeekDays);
            }
            return BadRequest();
        }

        public static IEnumerable<WeekDay> GetWeekDays(DateTime currentDate, bool? input)
        {
            for (int i = 0; i < 7; i++)
            {
                yield return new WeekDay { WeekOfDay = i.ToString() + ". " + currentDate.AddDays(i).DayOfWeek.ToString(), CurrentDate = currentDate.AddDays(i), hasParameter = input ?? false };
            }
        }
    }
}
