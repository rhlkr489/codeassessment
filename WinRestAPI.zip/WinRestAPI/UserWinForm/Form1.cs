﻿using CommonModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Windows.Forms;
using System.Linq;
namespace UserWinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.FillWeekdays();
        }

        private void FillWeekdays()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:64407/api/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                //HTTP GET
                var response = client.GetStringAsync("UserWeekday").Result;
                var data = JsonConvert.DeserializeObject<List<WeekDay>>(response);
                Weekdaybox.DataSource = new BindingSource(data, null);
                Weekdaybox.DisplayMember = "WeekOfDay";
                Weekdaybox.ValueMember = "CurrentDate";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var userInputDate = GetUserInputDate();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:64407/api/");
                client.DefaultRequestHeaders.Accept.Clear();
                //HTTP POST
                var myContent = JsonConvert.SerializeObject(userInputDate);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                var response = client.PostAsync("UserWeekday", byteContent).Result;
                var responseContents = response.Content.ReadAsStringAsync().Result;                
                if (response.IsSuccessStatusCode)
                {
                    var data = JsonConvert.DeserializeObject<List<WeekDay>>(responseContents);
                    Weekdaybox.DataSource = new BindingSource(data, null);
                    Weekdaybox.DisplayMember = "WeekOfDay";
                    Weekdaybox.ValueMember = "CurrentDate";
                    string message = "User Input Saved successfully! Please check dropdown";
                    string title = "Message";
                    MessageBox.Show(message, title);
                }
                else
                {
                    string message = "Please pass the input in date time";
                    string title = "Message";
                    MessageBox.Show(message, title);
                }
            }
        }

        private IEnumerable<WeekDay> GetUserInputDate()
        {
            for (int i = 0; i < UserInptTextBox.Lines.Length; i++)
            {                
                yield return new WeekDay { WeekOfDay = i.ToString() + ". " + Convert.ToDateTime(UserInptTextBox.Lines[i]).DayOfWeek.ToString(), CurrentDate = Convert.ToDateTime(UserInptTextBox.Lines[i]), hasParameter = false };
            }
        }
    }
}

